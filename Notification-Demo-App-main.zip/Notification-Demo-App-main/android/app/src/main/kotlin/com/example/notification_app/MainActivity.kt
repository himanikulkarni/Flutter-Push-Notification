package com.example.push_notification_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
